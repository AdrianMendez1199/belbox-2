<?php

	header("location: ../")

?>